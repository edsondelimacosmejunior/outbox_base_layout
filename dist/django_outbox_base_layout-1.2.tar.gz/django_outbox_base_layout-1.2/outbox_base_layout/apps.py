from django.apps import AppConfig


class OutboxBaseLayoutConfig(AppConfig):
    name = 'outbox_base_layout'
